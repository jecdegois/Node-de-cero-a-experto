

// function sumar( a, b ) {
//     return a + b;
// }

const sumar = (a, b) => a + b;

const saludar = () => 'Hola Mundo';


console.log(  sumar( 5, 10 )   );
console.log(  saludar()   );



