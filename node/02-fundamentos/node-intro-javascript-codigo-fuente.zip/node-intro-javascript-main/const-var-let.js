
const nombre = 'Wolverine';

if ( true ) {
   const nombre = 'Magneto';

//    console.log(nombre);
}

console.log(nombre);